from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()
leftWheel = Motor(Port.A, Direction.COUNTERCLOCKWISE)
leftAttachment = Motor(Port.B)
rightWheel = Motor(Port.E)
rightAttachment = Motor(Port.F)

driveBase = DriveBase(leftWheel,rightWheel,49.5,160)

driveBase.use_gyro(True)

driveBase.settings(straight_speed=700, turn_acceleration=500)

driveBase.straight(-15)
driveBase.reset()

driveBase.straight(740)
driveBase.turn(-43)
driveBase.straight(140)
leftAttachment.run_angle(500,-230)
rightAttachment.run_angle(310,160)
driveBase.curve(50,20)


rightAttachment.run_angle(500,-180)
