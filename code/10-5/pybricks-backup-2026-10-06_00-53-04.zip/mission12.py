from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()




leftWheel = Motor(Port.A, Direction.COUNTERCLOCKWISE)
leftAttachment = Motor(Port.B)
rightWheel = Motor(Port.E)
rightAttachment = Motor(Port.F)

DriveBase.settings
driveBase = DriveBase(leftWheel,rightWheel,49.5,160)
driveBase.use_gyro(True)


rightAttachment.run_angle(300,80)
driveBase.straight(500)
rightAttachment.run_angle(300,67)
leftAttachment.run_angle(300,-90)
driveBase.straight(-150)
rightAttachment.run_angle(300,-100)
driveBase.straight(-400)

