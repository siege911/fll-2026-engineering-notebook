from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()




leftWheel = Motor(Port.A, Direction.COUNTERCLOCKWISE)
leftAttachment = Motor(Port.B)
rightWheel = Motor(Port.E)
rightAttachment = Motor(Port.F)

driveBase = DriveBase(leftWheel,rightWheel,49.5,160)
driveBase.use_gyro(True)
driveBase.settings(straight_speed=600, straight_acceleration=600)

#driveBase.straight(710)
#driveBase.curve(180,45)
#driveBase.straight(100)
#rightAttachment.run_angle(500,400)
#rightAttachment.run_angle(500,-400)
driveBase.straight(-110)
leftAttachment.run_angle(500,170)
driveBase.turn(-70)
driveBase.straight(40)
leftAttachment.run_angle(750,-170)
driveBase.curve(-80,-115)
leftAttachment.run_angle(500,230)
driveBase.straight(200)
leftAttachment.run_angle(500,-140)
driveBase.straight(-200)
driveBase.turn(70)
driveBase.straight(610)