from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()


leftWheel = Motor(Port.A, Direction.COUNTERCLOCKWISE)
leftAttachment = Motor(Port.B)
rightWheel = Motor(Port.E)
rightAttachment = Motor(Port.F)

driveBase = DriveBase(leftWheel,rightWheel,49.5,160)

driveBase.use_gyro(True)

driveBase.settings(straight_speed=600, turn_rate=600)

driveBase.straight(-10)
driveBase.reset()

leftAttachment.run_angle(100, 240, wait=False)

driveBase.straight(140)
driveBase.turn(45)
driveBase.straight(680)
driveBase.turn(-50)
driveBase.straight(130)
rightAttachment.run_angle(100,-85)
rightAttachment.run_angle(100,80)
leftAttachment.run_angle(100,-120,wait=False)
driveBase.straight(-40)
driveBase.settings(straight_speed=100)
driveBase.straight(300)
driveBase.settings(straight_speed=600)
driveBase.straight(-280)
driveBase.turn(50)
driveBase.straight(-600)
driveBase.turn(50)