from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()
leftWheel = Motor(Port.A, Direction.COUNTERCLOCKWISE)
leftAttachment = Motor(Port.B)
rightWheel = Motor(Port.E)
rightAttachment = Motor(Port.F)

driveBase = DriveBase(leftWheel,rightWheel,49.5,147)

driveBase.straight(-15)
driveBase.straight(400)
driveBase.turn(-15.12)
driveBase.straight(70)
driveBase.straight(-300)
driveBase.turn(80)
driveBase.straight(480)
driveBase.turn(-17)
driveBase.straight(10)
rightAttachment.run_angle(500,260)
driveBase.straight(-500)